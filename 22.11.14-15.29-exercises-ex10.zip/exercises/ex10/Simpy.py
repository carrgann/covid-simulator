"""Utility class for numerical operations."""

from __future__ import annotations

from typing import Union

__author__ = "730567039"


class Simpy:
    """Based off NumPy."""
    values: list[float]

    def __init__(self, values: list[float]):
        """Constructor."""
        self.values = values

    def __repr__(self) -> str:
        """Magic method for simpy that will automagically convert to str."""
        return f"Simpy({self.values})"

    def fill(self, fil: float, numfil: int) -> None:
        """Fills simpy values with number of repeating values."""
        i: int = 0
        while i < numfil:
            self.values.append(fil)
            i += 1
        if len(self.values) != numfil:
            self.values = []
            i: int = 0
            while i < numfil:
                self.values.append(fil)
                i += 1
    
    def arange(self, start: float, stop: float, step: float = 1.0) -> None:
        """Fills values attribute with range of values."""
        while len(self.values) < (stop - start) / step:
            self.values.append(start + step * len(self.values))

    def sum(self) -> float:
        """Sum of all values in simpy."""
        return sum(self.values)
    
    def __add__(self, rhs: Union[Simpy, float]) -> Simpy:
        """Sum of two Simpys."""
        if type(self) == type(rhs):
            assert len(self.values) == len(rhs.values)
            result: Simpy = Simpy([])
            i: int = 0
            while i < len(self.values):
                result.values.append(self.values[i] + rhs.values[i])
                i += 1
            return result
        elif type(rhs) == float:
            new: Simpy = Simpy([])
            for num in self.values:
                new.values.append(num + rhs)
            return new
    
    def __pow__(self, rhs: Union[Simpy, float]) -> Simpy:
        """Raising simpys to the power of one another."""
        if type(self) == type(rhs):
            assert len(self.values) == len(rhs.values)
            result: Simpy = Simpy([])
            i: int = 0
            while i < len(self.values):
                result.values.append(self.values[i] ** rhs.values[i])
                i += 1
            return result
        elif type(rhs) == float:
            new: Simpy = Simpy([])
            for num in self.values:
                new.values.append(num ** rhs)
            return new

    def __eq__(self, rhs: Union[Simpy, float]) -> list[bool]:
        """Produce mask based on equality of each item in values att."""
        if type(self) == type(rhs):
            assert len(self.values) == len(rhs.values)
            result: list[bool] = []
            i: int = 0
            while i < len(self.values):
                if self.values[i] == rhs.values[i]:
                    result.append(True)
                else:
                    result.append(False)
                i += 1
            return result
        elif type(rhs) == float:
            new: list[bool] = []
            i: int = 0
            while i < len(self.values):
                if self.values[i] == rhs:
                    new.append(True)
                else:
                    new.append(False)
                i += 1
            return new

    def __gt__(self, rhs: Union[Simpy, float]) -> list[bool]:
        """Produce mask based on values attr relationships."""
        if type(self) == type(rhs):
            assert len(self.values) == len(rhs.values)
            result: list[bool] = []
            i: int = 0
            while i < len(self.values):
                if self.values[i] > rhs.values[i]:
                    result.append(True)
                else:
                    result.append(False)
                i += 1
            return result
        elif type(rhs) == float:
            new: list[bool] = []
            i: int = 0
            while i < len(self.values):
                if self.values[i] > rhs:
                    new.append(True)
                else:
                    new.append(False)
                i += 1
            return new
    
    def __getitem__(self, rhs: Union[int, list[bool]]) -> Union[float, Simpy]:
        """Subscription notation with Simpy objects."""
        if type(rhs) == int:
            return self.values[rhs]
        else:
            result: Simpy = Simpy([])
            i: int = 0
            while i < len(self.values):
                if rhs[i] is True:
                    result.values.append(self.values[i])
                i += 1
            return result


    
            
        
